// Gleiche Welle – kleiner Spielserver ohne Abhängigkeiten.
// Jeder Game-Code ist ein Raum. Spieler schicken ihren Stand per POST,
// der Server verteilt die Liste aller Spieler per Server-Sent Events an alle im Raum.
const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const INDEX = fs.readFileSync(path.join(__dirname, "public", "index.html"));
const ROOM_RE = /^gw-[a-z0-9]{4}$/;
const PEER_RE = /^[a-z0-9]{6,20}$/;
const MAX_ROOMS = 500;
const MAX_PEERS = 48;
const MAX_BODY = 8 * 1024;
const GRACE_MS = 15000;

// rooms: Map<room, Map<peer, { pr, clients: Set<res>, timer }>>
const rooms = new Map();

function snapshot(room) {
  const peers = [];
  for (const [id, p] of rooms.get(room) || []) peers.push({ id, pr: p.pr });
  return "data: " + JSON.stringify({ peers }) + "\n\n";
}
function broadcast(room) {
  const r = rooms.get(room);
  if (!r) return;
  const msg = snapshot(room);
  for (const p of r.values()) for (const res of p.clients) res.write(msg);
}
function getPeer(room, peer, create) {
  let r = rooms.get(room);
  if (!r) {
    if (!create || rooms.size >= MAX_ROOMS) return null;
    r = new Map();
    rooms.set(room, r);
  }
  let p = r.get(peer);
  if (!p && create) {
    if (r.size >= MAX_PEERS) return null;
    p = { pr: {}, clients: new Set(), timer: null };
    r.set(peer, p);
  }
  return p || null;
}
function removePeer(room, peer) {
  const r = rooms.get(room);
  if (!r || !r.has(peer)) return;
  const p = r.get(peer);
  clearTimeout(p.timer);
  for (const res of p.clients) res.end();
  r.delete(peer);
  if (r.size === 0) rooms.delete(room);
  else broadcast(room);
}

function readJson(req, cb) {
  let size = 0;
  const chunks = [];
  req.on("data", c => {
    size += c.length;
    if (size > MAX_BODY) { req.destroy(); return; }
    chunks.push(c);
  });
  req.on("end", () => {
    try { cb(JSON.parse(Buffer.concat(chunks).toString("utf8"))); } catch (e) { cb(null); }
  });
}
function reply(res, code, text) {
  res.writeHead(code, { "Content-Type": "text/plain; charset=utf-8" });
  res.end(text || "");
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");

  if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache" });
    return res.end(INDEX);
  }

  if (req.method === "GET" && url.pathname === "/api/events") {
    const room = url.searchParams.get("room"), peer = url.searchParams.get("peer");
    if (!ROOM_RE.test(room || "") || !PEER_RE.test(peer || "")) return reply(res, 400, "bad room");
    const p = getPeer(room, peer, true);
    if (!p) return reply(res, 503, "full");
    clearTimeout(p.timer);
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no"
    });
    res.write("retry: 2000\n\n");
    p.clients.add(res);
    res.write(snapshot(room));
    const ping = setInterval(() => res.write(": ping\n\n"), 20000);
    req.on("close", () => {
      clearInterval(ping);
      p.clients.delete(res);
      if (p.clients.size === 0) p.timer = setTimeout(() => removePeer(room, peer), GRACE_MS);
    });
    return;
  }

  if (req.method === "POST" && (url.pathname === "/api/presence" || url.pathname === "/api/leave")) {
    return readJson(req, body => {
      if (!body || !ROOM_RE.test(body.room || "") || !PEER_RE.test(body.peer || "")) return reply(res, 400, "bad request");
      if (url.pathname === "/api/leave") { removePeer(body.room, body.peer); return reply(res, 204); }
      if (typeof body.pr !== "object" || body.pr === null || Array.isArray(body.pr)) return reply(res, 400, "bad presence");
      const p = getPeer(body.room, body.peer, true);
      if (!p) return reply(res, 503, "full");
      p.pr = body.pr;
      broadcast(body.room);
      reply(res, 204);
    });
  }

  if (req.method === "GET" && url.pathname === "/health") return reply(res, 200, "ok");
  reply(res, 404, "Nicht gefunden");
});

server.listen(PORT, () => console.log("Gleiche Welle läuft auf http://localhost:" + PORT));
