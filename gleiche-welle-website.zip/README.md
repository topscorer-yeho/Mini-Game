# Gleiche Welle

Online-Partyspiel: Alle bekommen denselben Oberbegriff und schreiben auf dem eigenen Handy ein Wort. Ein Team punktet nur, wenn alle im Team dasselbe geschrieben haben. Wer ein Spiel erstellt, bekommt einen 4-stelligen Game-Code, mit dem die anderen beitreten.

## Dateien

- `server.js`: der Spielserver (Node.js, ohne zusätzliche Pakete)
- `public/index.html`: das Spiel im Browser
- `package.json`: sagt dem Hoster, wie der Server gestartet wird

## Kostenlos online stellen mit Render

1. Auf https://github.com ein kostenloses Konto anlegen und ein neues Repository erstellen (z. B. `gleiche-welle`).
2. Im Repository auf „uploading an existing file“ klicken und `server.js`, `package.json`, `README.md` und den Ordner `public` hochladen. Mit „Commit changes“ speichern.
3. Auf https://render.com mit dem GitHub-Konto anmelden.
4. „New“ → „Web Service“ wählen und das Repository verbinden.
5. Einstellungen:
   - Language: **Node**
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Instance Type: **Free**
6. „Deploy Web Service“ drücken. Nach ein bis zwei Minuten bekommst du eine Adresse wie `https://gleiche-welle.onrender.com`. Die schickst du deinen Freunden.

Hinweis: Der kostenlose Plan schläft nach etwa 15 Minuten ohne Besucher ein. Der erste Aufruf danach dauert bis zu einer Minute, danach läuft alles normal.

## Auf dem eigenen Computer ausprobieren

1. Node.js installieren (https://nodejs.org, Version 18 oder neuer).
2. Im Ordner ein Terminal öffnen und `npm start` eingeben.
3. Im Browser `http://localhost:3000` öffnen. Handys im selben WLAN erreichen das Spiel über die IP-Adresse des Computers, z. B. `http://192.168.0.23:3000`.

## Spielablauf

1. „Neues Spiel erstellen“: Teams, Spieler pro Team, Runden und persönliche Fragen einstellen.
2. Code oder Einladungslink an die anderen schicken. Jeder gibt seinen Namen ein und wählt ein Team.
3. Jede Runde schreibt jeder sein Wort. Sobald alle abgegeben haben, wird aufgedeckt.
4. Der Host startet die nächste Runde und kann bei Tippfehlern „Trotzdem zählen“ drücken.
